<html>
   <head>
      <title>MCMP Sales Engineering PHP Sample</title>
      <meta http-equiv=\Content-Type\ content=\text/html; charset=ISO-8859-1\>
   </head>
   <body>
      <h1>Welcome to the MCMP Sales Engineering PHP Sample</h1>
   </body>
</html>